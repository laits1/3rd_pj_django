# import os
#
# os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'main.settings')
# import django
# django.setup()

# import sys, os
# sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))

# print(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))
# from models import Movies

# from django.shortcuts import render
# import pandas as pd
# from django.db.models import Count
# import sqlite3
# import os.path

# from .models import Movies

# from ../main/models import models.Movies
# from ..main.models import Movies
# def mv() :
#
#     movie = Movies.objects.all()
#
#     print(movie)
#
#     return movie
#
# mv()