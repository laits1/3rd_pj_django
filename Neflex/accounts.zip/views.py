from django.shortcuts import redirect, render
from django.contrib.auth.hashers import make_password
import requests
from django.contrib.auth import authenticate, get_user_model
from django.contrib.auth.models import User
from .forms import CustomCreationForm
from django.contrib import auth
from . import myfunc
# Create your views here.
def after_login(request):

    print("gdsfafddasf")
    user = get_user_model().objects.get(pk=1)
    print(user.like_movie)


    a = myfunc.REC('Toy Story (1995)')
    print(a)

    movie_id = []
    movies = []
    for i in range(4) :
        movie_id.append(a.index[i])
        movies.append(a.iloc[i])
    print(movie_id)


    context = {
        'movies': movies
    }
    return render(request, 'accounts/after_login_page.html', context)


def login(request) :
    if request.method == 'POST' :
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None :
            auth.login(request, user)
            if user.like_movie:
                return redirect('accounts:after_login')
            return redirect('main:select')
        else :
            return render(request, 'accounts/login.html', {'error': 'username or password is incorrect.'})
    else :
        return render(request, 'accounts/login.html')


def logout(request) :
    auth.logout(request)
    return redirect('accounts:login')

def home(request) :
    return render(request, 'accounts/login.html')


def signup(request) :
    if request.method == 'POST':
        form = CustomCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('accounts:login')
        context={'form':form}
        print ('test')
        return render(request, 'accounts/signup.html', context)

        id = request.POST.get('name')
        password = request.POST.get('password')

        hashed_password = make_password(password)

        get_user_model().objects.create(
            username=id,
            password=hashed_password)
        return redirect('accounts:login')

    else:
        form = CustomCreationForm()

    context = {
        'form': form,
    }
    return render(request, 'accounts/signup.html', context)